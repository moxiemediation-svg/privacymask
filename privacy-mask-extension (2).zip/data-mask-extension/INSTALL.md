# Quick Installation Guide

## Install in Chrome (5 steps)

1. **Download the extension folder**
   - Make sure you have the entire `data-mask-extension` folder

2. **Open Chrome Extensions**
   - Type `chrome://extensions/` in your address bar
   - Or: Menu (⋮) → Extensions → Manage Extensions

3. **Enable Developer Mode**
   - Look for the toggle switch in the top-right corner
   - Turn it ON

4. **Load the Extension**
   - Click "Load unpacked" button
   - Navigate to and select the `data-mask-extension` folder
   - Click "Select Folder"

5. **Start Using It!**
   - Look for the 🔒 icon in your Chrome toolbar
   - Right-click any text to see "Mask sensitive data"

## First Test

Try this:
1. Select this text: `John Smith's email is john.smith@example.com and his phone is 555-123-4567`
2. Right-click → "Mask sensitive data"
3. You should see: `[NAME_1]'s email is [EMAIL_1] and his phone is [PHONE_1]`

## Troubleshooting

**Extension not showing?**
- Refresh the extensions page
- Make sure you selected the folder containing manifest.json

**Context menu not appearing?**
- Reload the page you're testing on
- Check that the extension is enabled

**Nothing happens when I click mask?**
- Check the browser console (F12) for errors
- Make sure you've selected text first

## Next Steps

Click the extension icon to:
- View the Mappings tab and see what's been masked
- Export your mappings as backup
- Try the bulk masking interface

---

Need help? Check the full README.md for detailed documentation.
