// Content script - runs on all webpages
const masker = new DataMasker();

// Initialize masker with stored mappings
masker.loadMappings();

// Listen for messages from background script
chrome.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
  if (request.action === 'maskSelection') {
    await handleMaskSelection(request.text);
  } else if (request.action === 'unmaskSelection') {
    await handleUnmaskSelection(request.text);
  } else if (request.action === 'copyMasked') {
    await handleCopyMasked(request.text);
  }
  sendResponse({ success: true });
  return true;
});

async function handleMaskSelection(selectedText) {
  await masker.loadMappings();
  
  // Default types - exclude 'name' as it's too aggressive
  const defaultTypes = ['email', 'phone', 'ssn', 'creditCard', 'amount', 'date', 'address'];
  
  const { maskedText, newMappings } = masker.maskText(selectedText, defaultTypes);
  
  // Save mappings
  await masker.saveMappings();
  
  // Replace the selected text with masked version
  replaceSelection(maskedText);
  
  // Show notification
  const count = Object.keys(newMappings).length;
  if (count > 0) {
    showNotification(`Masked ${count} sensitive item(s)`, 'success');
  } else {
    showNotification('No sensitive data detected', 'info');
  }
}

async function handleUnmaskSelection(selectedText) {
  await masker.loadMappings();
  
  const unmaskedText = masker.unmaskText(selectedText);
  
  // Replace the selected text with unmasked version
  replaceSelection(unmaskedText);
  
  showNotification('Data unmasked', 'success');
}

async function handleCopyMasked(selectedText) {
  await masker.loadMappings();
  
  // Default types - exclude 'name' as it's too aggressive
  const defaultTypes = ['email', 'phone', 'ssn', 'creditCard', 'amount', 'date', 'address'];
  
  const { maskedText, newMappings } = masker.maskText(selectedText, defaultTypes);
  
  // Save mappings
  await masker.saveMappings();
  
  // Copy to clipboard
  try {
    await navigator.clipboard.writeText(maskedText);
    const count = Object.keys(newMappings).length;
    showNotification(`Copied with ${count} item(s) masked`, 'success');
  } catch (err) {
    showNotification('Failed to copy to clipboard', 'error');
  }
}

function replaceSelection(newText) {
  const selection = window.getSelection();
  const activeElement = document.activeElement;
  
  // Check if we're in an editable field
  const isEditable = activeElement && (
    activeElement.tagName === 'TEXTAREA' || 
    activeElement.tagName === 'INPUT' ||
    activeElement.isContentEditable ||
    activeElement.getAttribute('contenteditable') === 'true'
  );
  
  if (isEditable && selection.rangeCount > 0) {
    // Replace in editable fields
    if (activeElement.tagName === 'TEXTAREA' || activeElement.tagName === 'INPUT') {
      const start = activeElement.selectionStart;
      const end = activeElement.selectionEnd;
      const text = activeElement.value;
      activeElement.value = text.substring(0, start) + newText + text.substring(end);
      activeElement.selectionStart = activeElement.selectionEnd = start + newText.length;
      
      // Trigger input event so the page knows text changed
      activeElement.dispatchEvent(new Event('input', { bubbles: true }));
      
      showNotification('✓ Text replaced with masked version', 'success');
    } else {
      // ContentEditable (like Google Docs)
      const range = selection.getRangeAt(0);
      range.deleteContents();
      range.insertNode(document.createTextNode(newText));
      showNotification('✓ Text replaced with masked version', 'success');
    }
  } else {
    // Not editable - copy to clipboard
    navigator.clipboard.writeText(newText).then(() => {
      showNotification('📋 Masked text copied to clipboard! Paste it where you need it.', 'info');
    }).catch(() => {
      showNotification('❌ Could not access clipboard. Try using the popup instead.', 'error');
    });
  }
}

function showNotification(message, type = 'info') {
  // Create notification element
  const notification = document.createElement('div');
  notification.className = `privacy-mask-notification privacy-mask-${type}`;
  notification.textContent = message;
  
  // Add to page
  document.body.appendChild(notification);
  
  // Auto-remove after 3 seconds
  setTimeout(() => {
    notification.style.opacity = '0';
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

// Listen for storage changes to keep masker in sync
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && (changes.maskMappings || changes.maskCounters)) {
    masker.loadMappings();
  }
});
