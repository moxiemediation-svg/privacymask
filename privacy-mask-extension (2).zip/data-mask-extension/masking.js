// Core masking logic - runs entirely client-side
class DataMasker {
  constructor() {
    this.patterns = {
      email: {
        regex: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g,
        prefix: 'EMAIL'
      },
      phone: {
        regex: /\b(\+\d{1,2}\s?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b/g,
        prefix: 'PHONE'
      },
      ssn: {
        regex: /\b\d{3}-\d{2}-\d{4}\b/g,
        prefix: 'SSN'
      },
      creditCard: {
        regex: /\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g,
        prefix: 'CARD'
      },
      amount: {
        regex: /\$\s?\d{1,3}(,\d{3})*(\.\d{2})?|\b\d{1,3}(,\d{3})*(\.\d{2})?\s?(dollars?|USD)\b/gi,
        prefix: 'AMOUNT'
      },
      date: {
        regex: /\b\d{1,2}\/\d{1,2}\/\d{2,4}\b|\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+\d{4}\b/gi,
        prefix: 'DATE'
      },
      address: {
        regex: /\b\d+\s+[A-Za-z0-9\s,]+(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Lane|Ln|Drive|Dr|Court|Ct|Circle|Cir|Way)\b/gi,
        prefix: 'ADDRESS'
      },
      name: {
        // More conservative: Requires First Last format with 4+ letters each
        // Still not perfect - use cautiously and review masked text
        regex: /\b[A-Z][a-z]{3,}\s+[A-Z][a-z]{3,}(?:\s+[A-Z][a-z]+)?\b/g,
        prefix: 'NAME'
      }
    };
    
    this.counters = {};
    this.mappings = {};
  }

  async loadMappings() {
    const result = await chrome.storage.local.get(['maskMappings', 'maskCounters']);
    this.mappings = result.maskMappings || {};
    this.counters = result.maskCounters || {};
  }

  async saveMappings() {
    await chrome.storage.local.set({
      maskMappings: this.mappings,
      maskCounters: this.counters
    });
  }

  maskText(text, selectedTypes = null) {
    let maskedText = text;
    const newMappings = {};
    const typesToMask = selectedTypes || Object.keys(this.patterns);

    // Process each pattern type
    typesToMask.forEach(type => {
      if (!this.patterns[type]) return;
      
      const { regex, prefix } = this.patterns[type];
      
      // Reset the regex
      regex.lastIndex = 0;
      
      maskedText = maskedText.replace(regex, (match) => {
        // Check if this value already has a mask
        let maskToken = Object.keys(this.mappings).find(
          key => this.mappings[key].original === match && key.startsWith(`[${prefix}_`)
        );

        if (!maskToken) {
          // Create new mask token
          if (!this.counters[prefix]) {
            this.counters[prefix] = 0;
          }
          this.counters[prefix]++;
          maskToken = `[${prefix}_${this.counters[prefix]}]`;
          
          this.mappings[maskToken] = {
            original: match,
            type: type,
            timestamp: new Date().toISOString()
          };
          
          newMappings[maskToken] = this.mappings[maskToken];
        }

        return maskToken;
      });
    });

    return { maskedText, newMappings };
  }

  unmaskText(text) {
    let unmaskedText = text;
    
    // Sort by token length (longest first) to avoid partial replacements
    const sortedTokens = Object.keys(this.mappings).sort((a, b) => b.length - a.length);
    
    sortedTokens.forEach(token => {
      const mapping = this.mappings[token];
      if (mapping && mapping.original) {
        unmaskedText = unmaskedText.split(token).join(mapping.original);
      }
    });

    return unmaskedText;
  }

  async clearMappings() {
    this.mappings = {};
    this.counters = {};
    await chrome.storage.local.remove(['maskMappings', 'maskCounters']);
  }

  async exportMappings() {
    return {
      mappings: this.mappings,
      counters: this.counters,
      exportDate: new Date().toISOString()
    };
  }

  async importMappings(data) {
    if (data.mappings) {
      this.mappings = { ...this.mappings, ...data.mappings };
    }
    if (data.counters) {
      this.counters = { ...this.counters, ...data.counters };
    }
    await this.saveMappings();
  }
}

// Make available globally
if (typeof window !== 'undefined') {
  window.DataMasker = DataMasker;
}
