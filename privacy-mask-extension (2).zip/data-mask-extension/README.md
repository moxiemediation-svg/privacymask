# Privacy Mask - Chrome Extension

A client-side data masking tool that lets you select sensitive text on any webpage, mask it, and safely share with AI tools. All processing happens locally in your browser - no data ever leaves your device.

## 🔒 Privacy First

- **100% client-side processing** - sensitive data never touches any server
- **Local storage only** - mappings stored in your browser
- **No tracking or analytics** - your data stays private
- **Perfect for compliance** - works with HIPAA, attorney-client privilege, trade secrets

## ✨ Features

- Right-click context menu to mask selected text
- Automatic detection of:
  - Names
  - Email addresses
  - Phone numbers
  - Social Security Numbers
  - Credit card numbers
  - Dollar amounts
  - Dates
  - Street addresses
- Export/import mappings for backup
- Easy unmask to restore original data
- Clean, intuitive interface

## 📦 Installation

### From Source (Developer Mode)

1. Download or clone this directory
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" (toggle in top-right corner)
4. Click "Load unpacked"
5. Select the `data-mask-extension` folder
6. The extension icon should appear in your toolbar

## 🚀 Usage

### Method 1: Context Menu (Right-click)

1. **Select text** on any webpage that contains sensitive data
2. **Right-click** and choose "Mask sensitive data"
3. The text will be replaced with masked tokens like `[NAME_1]`, `[EMAIL_1]`
4. **Copy the masked text** to use with ChatGPT, Claude, or other AI tools
5. When you get a response with masked tokens, select it and choose "Unmask data"

### Method 2: Extension Popup

1. Click the Privacy Mask icon in your toolbar
2. Paste text into the input field
3. Select which data types to mask (or leave all checked)
4. Click "Mask Text"
5. Copy the result and use it with your AI tool
6. To unmask AI responses, paste them back and click "Unmask Text"

### Method 3: Copy with Masking

1. Select text on any webpage
2. Right-click and choose "Copy with masking"
3. The masked version is copied to your clipboard
4. Paste directly into your AI tool

## 📊 Managing Mappings

Click the Privacy Mask icon and go to the "Mappings" tab to:

- **View all stored mappings** - see what's been masked
- **Export mappings** - download a JSON file as backup
- **Import mappings** - restore from a previous backup
- **Clear all mappings** - start fresh (careful - this can't be undone!)

## 🎯 Use Cases

### Legal Professionals
Mask client names, case numbers, and sensitive details before using AI to:
- Draft documents
- Research legal issues
- Analyze contracts
- Summarize depositions

### Healthcare
Mask patient information before using AI to:
- Draft clinical notes
- Research symptoms
- Generate patient education materials
- Analyze treatment plans

### HR & Employment
Mask employee names and salary info before using AI to:
- Draft policies
- Create job descriptions
- Analyze compensation data
- Generate training materials

### Business
Mask proprietary information before using AI to:
- Analyze financial data
- Draft contracts
- Research competitors
- Create reports

## ⚙️ Technical Details

### File Structure
```
data-mask-extension/
├── manifest.json          # Extension configuration
├── background.js          # Context menu handler
├── content.js            # Webpage interaction
├── content.css           # Notification styling
├── masking.js            # Core masking logic
├── popup.html            # Extension popup interface
├── popup.js              # Popup logic
├── popup.css             # Popup styling
├── icon16.png            # Extension icon (16x16)
├── icon48.png            # Extension icon (48x48)
└── icon128.png           # Extension icon (128x128)
```

### Data Storage

All data is stored using Chrome's `chrome.storage.local` API:
- `maskMappings`: Object mapping tokens to original values
- `maskCounters`: Counters for each data type

Storage is isolated per-user and never synced.

### Pattern Detection

The extension uses regular expressions to detect:
- **Emails**: Standard email format
- **Phone numbers**: Various US formats
- **SSNs**: XXX-XX-XXXX format
- **Credit cards**: 16-digit numbers with optional separators
- **Amounts**: Dollar amounts with $ or "dollars"
- **Dates**: Multiple date formats
- **Addresses**: Street addresses with common suffixes
- **Names**: Capitalized word sequences (basic detection)

## 🔧 Customization

To modify detection patterns, edit the `patterns` object in `masking.js`. Each pattern has:
- `regex`: Regular expression for detection
- `prefix`: Prefix for masked tokens (e.g., "EMAIL" → `[EMAIL_1]`)

## 🚨 Important Notes

1. **Name detection is basic** - it may mask some non-names or miss some names
2. **Export your mappings regularly** - if you clear browser data, mappings are lost
3. **Mappings persist across sessions** - stored until you clear them or clear browser data
4. **The extension cannot unmask data without mappings** - keep your exports safe!

## 🛡️ Security & Privacy

- No network requests are made by this extension
- No data is sent to any external server
- No analytics or tracking
- All processing happens in your browser
- Mappings are stored locally only
- Open source - review the code yourself

## 📝 License

This extension is provided as-is for privacy-conscious users. Feel free to modify and distribute.

## 🐛 Troubleshooting

**Q: The context menu doesn't appear**
A: Make sure the extension is enabled in chrome://extensions/

**Q: Masked text isn't being replaced on the page**
A: The page may be read-only. Use "Copy with masking" instead.

**Q: I lost my mappings**
A: If you cleared browser data or didn't export, mappings are permanently lost. Export regularly!

**Q: Can I use this with Firefox?**
A: Not yet, but the code could be adapted (Firefox uses WebExtensions API)

## 💡 Tips

- Export your mappings before clearing browser data
- Use specific selections to avoid masking too much
- For very sensitive work, export mappings to an encrypted drive
- Test with sample data first to understand how masking works
- Combine with AI providers that don't train on your data for maximum privacy

## 🤝 Contributing

Found a bug? Want to add a feature? Contributions welcome!

---

**Remember**: This tool masks data in your browser, but you should still review masked text before sharing to ensure nothing sensitive leaked through. No automated system is perfect!
