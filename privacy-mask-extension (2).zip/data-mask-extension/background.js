// Background service worker for context menu
chrome.runtime.onInstalled.addListener(() => {
  // Create context menu items
  chrome.contextMenus.create({
    id: 'maskSelectedText',
    title: 'Mask sensitive data',
    contexts: ['selection']
  });

  chrome.contextMenus.create({
    id: 'unmaskSelectedText',
    title: 'Unmask data',
    contexts: ['selection']
  });

  chrome.contextMenus.create({
    id: 'copyMasked',
    title: 'Copy with masking',
    contexts: ['selection']
  });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'maskSelectedText') {
    chrome.tabs.sendMessage(tab.id, {
      action: 'maskSelection',
      text: info.selectionText
    });
  } else if (info.menuItemId === 'unmaskSelectedText') {
    chrome.tabs.sendMessage(tab.id, {
      action: 'unmaskSelection',
      text: info.selectionText
    });
  } else if (info.menuItemId === 'copyMasked') {
    chrome.tabs.sendMessage(tab.id, {
      action: 'copyMasked',
      text: info.selectionText
    });
  }
});

// Handle messages from content script or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'showNotification') {
    // Could add notification here if needed
    console.log('Notification:', request.message);
  }
  return true;
});
