// Popup logic
const masker = new DataMasker();

// DOM elements
const tabs = document.querySelectorAll('.tab-button');
const tabContents = document.querySelectorAll('.tab-content');
const inputText = document.getElementById('input-text');
const outputText = document.getElementById('output-text');
const maskBtn = document.getElementById('mask-btn');
const unmaskBtn = document.getElementById('unmask-btn');
const copyBtn = document.getElementById('copy-btn');
const exportBtn = document.getElementById('export-btn');
const importBtn = document.getElementById('import-btn');
const clearBtn = document.getElementById('clear-btn');
const importFile = document.getElementById('import-file');
const maskStats = document.getElementById('mask-stats');
const mappingsList = document.getElementById('mappings-list');
const maskTypeCheckboxes = document.querySelectorAll('.mask-type');

// Initialize
loadMappings();

// Tab switching
tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    const tabName = tab.dataset.tab;
    
    // Update active states
    tabs.forEach(t => t.classList.remove('active'));
    tabContents.forEach(tc => tc.classList.remove('active'));
    
    tab.classList.add('active');
    document.getElementById(`${tabName}-tab`).classList.add('active');
    
    // Refresh mappings list if switching to mappings tab
    if (tabName === 'mappings') {
      displayMappings();
    }
  });
});

// Mask button
maskBtn.addEventListener('click', async () => {
  const text = inputText.value.trim();
  if (!text) {
    showStats('Please enter some text to mask', 'error');
    return;
  }

  await masker.loadMappings();
  
  // Get selected mask types
  const selectedTypes = Array.from(maskTypeCheckboxes)
    .filter(cb => cb.checked)
    .map(cb => cb.value);

  if (selectedTypes.length === 0) {
    showStats('Please select at least one data type to mask', 'error');
    return;
  }

  const { maskedText, newMappings } = masker.maskText(text, selectedTypes);
  
  await masker.saveMappings();
  
  outputText.value = maskedText;
  
  const count = Object.keys(newMappings).length;
  if (count > 0) {
    showStats(`✓ Masked ${count} sensitive item(s)`, 'success');
  } else {
    showStats('ℹ No sensitive data detected', 'info');
  }
  
  displayMappings();
});

// Unmask button
unmaskBtn.addEventListener('click', async () => {
  const text = inputText.value.trim();
  if (!text) {
    showStats('Please enter some text to unmask', 'error');
    return;
  }

  await masker.loadMappings();
  
  const unmaskedText = masker.unmaskText(text);
  outputText.value = unmaskedText;
  
  showStats('✓ Data unmasked', 'success');
});

// Copy button
copyBtn.addEventListener('click', async () => {
  const text = outputText.value.trim();
  if (!text) {
    showStats('Nothing to copy', 'error');
    return;
  }

  try {
    await navigator.clipboard.writeText(text);
    showStats('✓ Copied to clipboard', 'success');
  } catch (err) {
    showStats('Failed to copy', 'error');
  }
});

// Export button
exportBtn.addEventListener('click', async () => {
  await masker.loadMappings();
  const data = await masker.exportMappings();
  
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `privacy-mask-mappings-${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
  
  showStats('✓ Mappings exported', 'success');
});

// Import button
importBtn.addEventListener('click', () => {
  importFile.click();
});

// Import file handler
importFile.addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;

  try {
    const text = await file.text();
    const data = JSON.parse(text);
    
    await masker.importMappings(data);
    await loadMappings();
    displayMappings();
    
    showStats('✓ Mappings imported', 'success');
  } catch (err) {
    showStats('Failed to import mappings', 'error');
  }
  
  // Reset file input
  importFile.value = '';
});

// Clear button
clearBtn.addEventListener('click', async () => {
  if (!confirm('Are you sure you want to clear all mappings? This cannot be undone.')) {
    return;
  }

  await masker.clearMappings();
  await loadMappings();
  displayMappings();
  
  showStats('✓ All mappings cleared', 'success');
});

// Helper functions
async function loadMappings() {
  await masker.loadMappings();
}

function displayMappings() {
  const mappings = masker.mappings;
  const tokens = Object.keys(mappings);
  
  if (tokens.length === 0) {
    mappingsList.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">🔐</div>
        <div>No mappings yet</div>
        <div style="font-size: 12px; margin-top: 8px;">Mask some data to see it here</div>
      </div>
    `;
    return;
  }

  // Sort tokens by timestamp (newest first)
  tokens.sort((a, b) => {
    const timeA = new Date(mappings[a].timestamp || 0);
    const timeB = new Date(mappings[b].timestamp || 0);
    return timeB - timeA;
  });

  mappingsList.innerHTML = tokens.map(token => {
    const mapping = mappings[token];
    const date = new Date(mapping.timestamp).toLocaleString();
    
    return `
      <div class="mapping-item">
        <div class="mapping-header">
          <span class="mapping-token">${escapeHtml(token)}</span>
          <span class="mapping-type">${escapeHtml(mapping.type)}</span>
        </div>
        <div class="mapping-value">${escapeHtml(mapping.original)}</div>
        <div class="mapping-meta">Created: ${date}</div>
      </div>
    `;
  }).join('');
}

function showStats(message, type = 'info') {
  maskStats.textContent = message;
  maskStats.className = `stats show ${type}`;
  
  setTimeout(() => {
    maskStats.classList.remove('show');
  }, 3000);
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Listen for storage changes
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && (changes.maskMappings || changes.maskCounters)) {
    loadMappings();
    displayMappings();
  }
});
